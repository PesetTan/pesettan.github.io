# Install the INBRND educational flywheel in Wix

## What is ready

The current delivery has two presentations of the approved design: with teaching copy and just the circle. One reusable custom element powers both. No live Wix content was edited.

Start with the matching step-by-step runbook:

- [With teaching copy](wix-teaching-copy-runbook.md)
- [Just the circle](wix-diagram-only-runbook.md)

The package also includes standalone examples and matching Velo page-code files. Older design variants remain supported for reference, but are not the current two-version review.

- Component: **inbrnd-flywheel.js** (styles embedded and isolated in Shadow DOM)
- Tag name: **inbrnd-flywheel**
- Design options: **wheel**, **sculpted**, **editorial**, **thread**
- Assets: **assets/**
- Installable archive: **../releases/inbrnd-flywheel-wix.zip**

The component contains the educational introduction, five lessons, flywheel and educational closing. Preview header, navigation, review links and footer are separate. Use Wix’s existing site chrome.

## Recommended installation

1. Start on a duplicate/test page of the INBRND Wix site.
2. Place the supplied component and assets on an HTTPS host you control, or use a Wix Velo custom-element file for the JavaScript and accessible HTTPS URLs for the assets. The owner-private ChatGPT Site is a review destination; its protected URLs are not production asset URLs for public Wix visitors.
3. In Wix, choose **Add Elements → Embed Code → Custom Element**. Select **Server URL** and enter the component JavaScript URL, or select its Velo file.
4. Set the element’s tag name to **inbrnd-flywheel**.
5. Configure its attributes using Wix’s Set Attributes panel where available, or the Velo snippet below.
6. Place it in a full-width section. Let its height follow its content, with no fixed-height clipping or internal vertical scrollbar. Keep ancestor containers’ vertical overflow visible and avoid transformed ancestors that constrain sticky positioning.
7. Set Wix’s responsive width to fill the section. The component handles its own desktop/mobile breakpoints.
8. Verify on a published Wix test site before replacing the existing educational section. Wix’s editor and Preview put custom elements in an iframe, so sticky/page-scroll behavior there is not a reliable production test.

The component uses document scrolling. Do not put the whole private preview page into an “Embed HTML” iframe: that creates a separate scrolling context and does not provide the intended page-scroll choreography.

## Attributes

| Attribute | Value / default |
| --- | --- |
| variant | wheel (default), sculpted, editorial, or thread |
| asset-base | Absolute HTTPS directory containing editors-note-regular.woff2 and editors-note-hairline.otf; include the trailing slash. Default ./assets/ is suitable for the bundled local example only. |
| heading-level | Intro heading level, 1–6. Default 2 for inclusion within an existing Wix page. Standalone preview pages use 1. |
| header-offset | Sticky Wix header height in CSS pixels, such as 80. Default 0. Do not include px. |

Example Velo page code (replace the element ID and asset URL):

~~~js
$w.onReady(() => {
  const flywheel = $w('#inbrndFlywheel');
  flywheel.setAttribute('variant', 'wheel');
  flywheel.setAttribute('asset-base', 'https://YOUR-ASSET-HOST/inbrnd/assets/');
  flywheel.setAttribute('header-offset', '80');
});
~~~

If the Wix header has a different mobile height, configure the appropriate offset for that breakpoint in your page code. The component recomputes when its attributes or viewport change.

For a regular HTML host:

~~~html
<script defer src="./inbrnd-flywheel.js"></script>
<inbrnd-flywheel
  variant="wheel"
  asset-base="./assets/"
  header-offset="0">
</inbrnd-flywheel>
~~~

When serving fonts from another origin, configure the asset host to permit font requests from the INBRND domain using CORS. Serve JavaScript as JavaScript, WOFF2 files as font/woff2, and OTF files as font/otf.

## Layout and behavior

- Main layouts use a sticky composition; normal document scrolling drives every frame.
- At widths up to 900 CSS pixels, the diagram sits above the copy. Its nominal height is 36svh, within a 40svh graphic region.
- When the available viewport height after header offset is 480 CSS pixels or less (or below 680px tall at mobile/tablet widths), the experience becomes an unpinned sequence. The full diagram and teaching content appear in normal reading order.
- With prefers-reduced-motion: reduce, the complete system and all five lessons appear in normal reading order. “Read without motion” offers the same presentation without changing operating-system settings.
- Ordinary Tab/Enter navigation and scrolling remain available. All teaching content is available to assistive technology.
- The component disconnects its scroll/resize/media listeners and ResizeObserver when removed.
- The introduction defaults to a level-two heading for inclusion in an existing page; set heading-level to 1 only when it is the page’s main heading.

## Published Wix test-site checklist

- Confirm all assets load for a logged-out visitor.
- Confirm no clipping, double scrollbars, parent overflow restriction, or unexpected section height.
- Check Positioning at the top, followed clockwise by Narrative, Platforms, Opportunities, Signals and the return to Positioning.
- Check partially drawn incoming arrows and rose segments.
- Check that Authority / Recognition and Career Momentum appear only after the closing arrow.
- Scroll back to earlier points and verify exact reversal.
- Confirm the pinned area clears the Wix header and releases before the next Wix section.
- Check narrow phones, portrait tablet, desktop, phone landscape and browser zoom.
- Check reduced motion, keyboard focus, and reading order.
- Check back/forward navigation and reload at a mid-story scroll position.
- Only after that verification should the chosen variant replace the existing live section.

## Verification boundary

The component and routes were tested in a local browser. This delivery does **not** include installation or execution inside Wix, and does not certify the Wix page’s parent-container settings. The remaining Wix checks above require the actual Wix environment.

Official references:
- [Wix custom elements and requirements](https://support.wix.com/en/article/wix-editor-adding-a-custom-element-to-your-site)
- [Custom elements in Velo](https://dev.wix.com/docs/develop-websites/articles/wix-editor-elements/custom-elements/about-custom-elements)
- [HTML component iframe isolation](https://dev.wix.com/docs/velo/api-reference/$w/html-component/introduction)

## Optional presentation attributes

- content-mode="diagram": hide primary editorial/teaching text and center a larger diagram. Omit for the standard teaching layout.
- theme="rose": use the retained alternate charcoal-ring palette; the page remains ivory. Omit for the original ivory palette.
- These options work independently of variant, and ring labels retain matched typography.

- emphasis="ring" (default), "sector", or "center": choose the active-phase indicator: a subtle ivory ring highlight, a soft rose wash, or a central title with subtle gradient focus. The ring’s advancing edge fades in during assembly and settles to a solid perimeter. Works with either teaching-copy mode. Highlights disappear as the complete system resolves.


## October 20 refinement

The five-stage system completes at 80% of the existing scroll travel. The teaching version reveals “As authority and recognition compound, career momentum grows.” between 80% and 85%, then holds the completed composition through 100%. The outer ring changes uniformly from soft pink to burgundy and grows from 12 to 13 SVG units. Its lower label is Career Momentum. The circle-only version retains no visible explanatory copy.

Stage emphasis uses solid color and opacity. There is no scaling, gradient highlight, scroll interception, or time-driven animation. Reduced motion and short screens display the complete system in normal flow.

The standalone HTML examples include the complete static diagram and five explanations before JavaScript initializes; they also work if the component script fails. A Wix Editor custom element does not automatically inherit this surrounding HTML, so the equivalent host-page fallback must be validated during Wix installation.

Public preview: https://pesettan.github.io/inbrnd/

Before and after: https://pesettan.github.io/inbrnd/comparison/

Preserved original: https://pesettan.github.io/inbrnd/before/

Wix installation and physical-device testing are not implied by GitHub Pages validation.
